package com.jsonbook.Json.Book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonBookApplication.class, args);
	}

}
